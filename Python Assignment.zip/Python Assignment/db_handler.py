import pandas as pd
import pyodbc
import os
import sys

# ============================================================
# DATABASE CONFIGURATION
# ============================================================

SERVER = r"DESKTOP-NOUVV6C\SQLEXPRESS"
DATABASE = "ProductDB"
TABLE = "Products"

CSV_FILE = "clean_products.csv"


# ============================================================
# HELPER FUNCTION
# ============================================================

def find_column(df, possible_names):
    """
    Finds a column from a list of possible column names.
    Matching is case-insensitive.
    """

    column_map = {
        str(col).strip().lower(): col
        for col in df.columns
    }

    for name in possible_names:
        if name.lower() in column_map:
            return column_map[name.lower()]

    return None


# ============================================================
# LOAD CLEAN DATA
# ============================================================

print("\n" + "=" * 60)
print("DATABASE INTEGRATION")
print("=" * 60)

if not os.path.exists(CSV_FILE):
    print(f"\nERROR: {CSV_FILE} not found.")
    sys.exit(1)

df = pd.read_csv(CSV_FILE)

print(f"Cleaned records loaded: {len(df)}")
print("\nCSV columns detected:")
print(list(df.columns))


# ============================================================
# FIND REQUIRED COLUMNS
# ============================================================

product_id_col = find_column(
    df,
    [
        "Product_ID",
        "Product ID",
        "product_id",
        "id"
    ]
)

product_name_col = find_column(
    df,
    [
        "Product_Name",
        "Product Name",
        "product_name",
        "title",
        "Title"
    ]
)

category_col = find_column(
    df,
    [
        "Category",
        "category"
    ]
)

price_col = find_column(
    df,
    [
        "Price",
        "price",
        "final_price",
        "Final_Price"
    ]
)

rating_col = find_column(
    df,
    [
        "Rating",
        "rating",
        "average_score",
        "Average_Score"
    ]
)

revenue_col = find_column(
    df,
    [
        "Total_Revenue",
        "total_estimated_revenue",
        "Total_Estimated_Revenue",
        "revenue"
    ]
)


# ============================================================
# DISPLAY COLUMN MAPPING
# ============================================================

print("\nColumn mapping:")
print(f"Product ID : {product_id_col}")
print(f"Product Name: {product_name_col}")
print(f"Category   : {category_col}")
print(f"Price      : {price_col}")
print(f"Rating     : {rating_col}")
print(f"Revenue    : {revenue_col}")


# ============================================================
# VALIDATE REQUIRED COLUMNS
# ============================================================

missing = []

if product_id_col is None:
    missing.append("Product_ID")

if product_name_col is None:
    missing.append("Product_Name")

if category_col is None:
    missing.append("Category")

if price_col is None:
    missing.append("Price")

if rating_col is None:
    missing.append("Rating")

if missing:
    print("\n" + "=" * 60)
    print("DATABASE ERROR")
    print("=" * 60)

    print(f"Missing required columns: {missing}")

    print("\nAvailable columns:")
    for col in df.columns:
        print(f" - {col}")

    sys.exit(1)


# ============================================================
# CLEAN DATA FOR DATABASE
# ============================================================

df[product_id_col] = df[product_id_col].astype(str).str.strip()
df[product_name_col] = df[product_name_col].astype(str).str.strip()
df[category_col] = df[category_col].astype(str).str.strip()

df[price_col] = pd.to_numeric(
    df[price_col],
    errors="coerce"
).fillna(0)

df[rating_col] = pd.to_numeric(
    df[rating_col],
    errors="coerce"
).fillna(0)

if revenue_col is not None:
    df[revenue_col] = pd.to_numeric(
        df[revenue_col],
        errors="coerce"
    ).fillna(0)


# ============================================================
# REMOVE DUPLICATE PRODUCT IDS
# ============================================================

before = len(df)

df = df.drop_duplicates(
    subset=[product_id_col],
    keep="first"
)

duplicates_removed = before - len(df)

print(f"\nDuplicate records removed: {duplicates_removed}")
print(f"Records ready for database: {len(df)}")


# ============================================================
# SQL SERVER CONNECTION
# ============================================================

connection_string = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    f"SERVER={SERVER};"
    "DATABASE=master;"
    "Trusted_Connection=yes;"
)

try:

    conn = pyodbc.connect(
        connection_string,
        autocommit=True
    )

    cursor = conn.cursor()

    print("\nConnected to SQL Server successfully.")


    # ========================================================
    # CREATE DATABASE IF NOT EXISTS
    # ========================================================

    cursor.execute(
        f"""
        IF DB_ID('{DATABASE}') IS NULL
        BEGIN
            CREATE DATABASE [{DATABASE}]
        END
        """
    )

    cursor.close()
    conn.close()


    # ========================================================
    # CONNECT TO ProductDB
    # ========================================================

    connection_string = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        f"SERVER={SERVER};"
        f"DATABASE={DATABASE};"
        "Trusted_Connection=yes;"
    )

    conn = pyodbc.connect(connection_string)
    cursor = conn.cursor()

    print(f"{DATABASE} database is ready.")


    # ========================================================
    # CREATE PRODUCTS TABLE
    # ========================================================

    cursor.execute(
        f"""
        IF OBJECT_ID('dbo.{TABLE}', 'U') IS NULL
        BEGIN

            CREATE TABLE dbo.{TABLE}
            (
                Product_ID NVARCHAR(300) NOT NULL PRIMARY KEY,
                Product_Name NVARCHAR(500) NOT NULL,
                Category NVARCHAR(200),
                Price DECIMAL(10,2),
                Rating DECIMAL(4,2),
                Total_Revenue DECIMAL(12,2)
            )

        END
        """
    )

    conn.commit()

    print("Products table is ready.")


    # ========================================================
    # INSERT ALL 100 RECORDS
    # ========================================================

    inserted = 0
    skipped = 0

    for _, row in df.iterrows():

        product_id = str(row[product_id_col])
        product_name = str(row[product_name_col])
        category = str(row[category_col])

        price = float(row[price_col])
        rating = float(row[rating_col])

        if revenue_col is not None:
            revenue = float(row[revenue_col])
        else:
            revenue = 0.0

        # Check whether record already exists
        cursor.execute(
            f"""
            SELECT COUNT(*)
            FROM dbo.{TABLE}
            WHERE Product_ID = ?
            """,
            product_id
        )

        exists = cursor.fetchone()[0]

        if exists == 0:

            cursor.execute(
                f"""
                INSERT INTO dbo.{TABLE}
                (
                    Product_ID,
                    Product_Name,
                    Category,
                    Price,
                    Rating,
                    Total_Revenue
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                product_id,
                product_name,
                category,
                price,
                rating,
                revenue
            )

            inserted += 1

        else:
            skipped += 1


    conn.commit()

    print("\n" + "=" * 60)
    print("INSERTION RESULT")
    print("=" * 60)

    print(f"CSV records available : {len(df)}")
    print(f"Records inserted      : {inserted}")
    print(f"Records already exist : {skipped}")


    # ========================================================
    # ACTUAL DATABASE COUNT
    # ========================================================

    cursor.execute(
        f"""
        SELECT COUNT(*)
        FROM dbo.{TABLE}
        """
    )

    database_count = cursor.fetchone()[0]

    print(f"Actual database count  : {database_count}")


    # ========================================================
    # SHOW ALL RECORDS
    # ========================================================

    print("\n" + "=" * 60)
    print("ALL RECORDS")
    print("=" * 60)

    cursor.execute(
        f"""
        SELECT
            Product_ID,
            Product_Name,
            Category,
            Price,
            Rating,
            Total_Revenue
        FROM dbo.{TABLE}
        ORDER BY Product_Name
        """
    )

    rows = cursor.fetchall()

    for row in rows:
        print(row)


    # ========================================================
    # TOP 10 PRODUCTS BY PRICE
    # ========================================================

    print("\n" + "=" * 60)
    print("TOP 10 PRODUCTS BY PRICE")
    print("=" * 60)

    cursor.execute(
        f"""
        SELECT TOP 10
            Product_ID,
            Product_Name,
            Category,
            Price,
            Rating,
            Total_Revenue
        FROM dbo.{TABLE}
        ORDER BY Price DESC
        """
    )

    rows = cursor.fetchall()

    for row in rows:
        print(row)


    # ========================================================
    # PRODUCT COUNT PER CATEGORY
    # ========================================================

    print("\n" + "=" * 60)
    print("PRODUCT COUNT PER CATEGORY")
    print("=" * 60)

    cursor.execute(
        f"""
        SELECT
            Category,
            COUNT(*) AS Product_Count
        FROM dbo.{TABLE}
        GROUP BY Category
        ORDER BY Category
        """
    )

    category_rows = cursor.fetchall()

    for row in category_rows:
        print(
            f"Category: {row[0]}, "
            f"Count: {row[1]}"
        )


    # ========================================================
    # FINAL VALIDATION
    # ========================================================

    print("\n" + "=" * 60)
    print("FINAL DATABASE VALIDATION")
    print("=" * 60)

    print(f"Expected records : {len(df)}")
    print(f"Actual DB records: {database_count}")

    if database_count == len(df):
        print("\nSUCCESS: All records are present in ProductDB.")
    else:
        print(
            "\nWARNING: Database count does not match "
            "the expected CSV record count."
        )


    # ========================================================
    # CLOSE CONNECTION
    # ========================================================

    cursor.close()
    conn.close()

    print("\nDatabase connection closed.")

    print("\n" + "=" * 60)
    print("DATABASE INTEGRATION COMPLETED")
    print("=" * 60)


except pyodbc.Error as e:

    print("\n" + "=" * 60)
    print("DATABASE ERROR")
    print("=" * 60)

    print(f"Error: {e}")

    sys.exit(1)